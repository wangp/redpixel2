#ifndef __included_ugbutton_h
#define __included_ugbutton_h


void ug_button_set_extra (ug_widget_t *p, void *extra);
void *ug_button_extra (ug_widget_t *p);


#endif
