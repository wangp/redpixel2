#ifndef __included_modebar_h
#define __included_modebar_h


void modebar_install (int x, int y, int w, int h);
void modebar_uninstall ();


#endif
