#ifndef __included_gameclt_h
#define __included_gameclt_h


int game_client_init (const char *addr);
void game_client ();
void game_client_shutdown ();


#endif
