-- explode.lua


-- Module init.

store_load ("object/explode.dat", "/explodable/")
objtype_register ("objtile", "barrel-red",	"/explodable/barrel-000")
objtype_register ("objtile", "barrel-grey",	"/explodable/barrel-001")
objtype_register ("objtile", "crate-0",		"/explodable/crate-000")
objtype_register ("objtile", "crate-1",		"/explodable/crate-001")
objtype_register ("objtile", "crate-big",	"/explodable/crate-big-000")
objtype_register ("objtile", "wood-0",		"/explodable/wood-000")
objtype_register ("objtile", "wood-1",		"/explodable/wood-001")
objtype_register ("objtile", "wood-2",		"/explodable/wood-002")
objtype_register ("objtile", "wood-3",		"/explodable/wood-003")
objtype_register ("objtile", "wood-4",		"/explodable/wood-004")
objtype_register ("objtile", "wood-5",		"/explodable/wood-005")
