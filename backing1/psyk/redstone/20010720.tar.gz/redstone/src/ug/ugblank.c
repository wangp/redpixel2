/* ugblank.c
 *
 * Peter Wang <tjaden@users.sourceforge.net>
 */


#include "ug.h"
#include "uginter.h"


ug_widget_class_t ug_blank = {
    0, 0, 0
};
