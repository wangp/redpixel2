-- editor-init.lua

store_load ("editor/editor-support.dat", "/editor/")
