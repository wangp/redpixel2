#ifndef __included_menu_h
#define __included_menu_h


void menu_install (int x, int y, int w, int h);
void menu_uninstall ();


#endif
