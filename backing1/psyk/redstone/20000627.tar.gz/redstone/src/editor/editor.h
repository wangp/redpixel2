#ifndef __included_editor_h
#define __included_editor_h


#include "map.h"


extern map_t *map;


#endif
