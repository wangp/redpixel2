/* Positive is higher.  */

#define DEPTH_TILES	0
#define DEPTH_LIGHTS	100
