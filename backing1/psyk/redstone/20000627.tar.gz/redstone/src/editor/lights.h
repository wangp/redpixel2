#ifndef __included_lights_h
#define __included_lights_h


int lights_init ();
void lights_shutdown ();


#endif
