#ifndef __included_tiles_h
#define __included_tiles_h


int tiles_init ();
void tiles_shutdown ();


#endif
