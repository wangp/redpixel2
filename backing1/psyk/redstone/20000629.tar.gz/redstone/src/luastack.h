#ifndef __included_luastack_h
#define __included_luastack_h


#include <lua.h>

void luastack_init (lua_State *);


#endif
