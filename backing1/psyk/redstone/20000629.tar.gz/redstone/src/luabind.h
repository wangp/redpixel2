#ifndef __included_luabind_h
#define __included_luabind_h


void luabind_init ();
void luabind_shutdown ();


#endif
