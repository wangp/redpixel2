#ifndef __included_gameloop_h
#define __included_gameloop_h


void game_loop ();


#endif
