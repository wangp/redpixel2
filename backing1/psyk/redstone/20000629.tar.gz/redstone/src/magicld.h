#ifndef __included_magicld_h
#define __included_magicld_h


DATAFILE *load_magic_datafile (const char *filename);


#endif
