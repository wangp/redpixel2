#ifndef __included_objmin_h
#define __included_objmin_h


/* Include this header when a module needs to know about objects, but
 * doesn't need to know about the internals or object functions.  */


typedef struct object object_t;


#endif
