/* Positive is higher.  */

#define DEPTH_TILES	0
#define DEPTH_OBJECTS	50
#define DEPTH_LIGHTS	100
