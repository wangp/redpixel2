#ifndef __included_bindings_h
#define __included_bindings_h


void bindings_init ();
void bindings_shutdown ();


#endif
