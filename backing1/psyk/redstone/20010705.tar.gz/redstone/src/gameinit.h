void game_init ();
void game_shutdown ();
