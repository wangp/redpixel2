#ifndef __included_gamesrv_h
#define __included_gamesrv_h


int game_server_init ();
void game_server ();
void game_server_shutdown ();


#endif
