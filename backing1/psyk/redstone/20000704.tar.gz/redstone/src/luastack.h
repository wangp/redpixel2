void lua_enablestacktraceback (lua_State *);
