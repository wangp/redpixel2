extern FONT _new_font;
