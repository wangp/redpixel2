DATAFILE *load_extended_datafile (const char *filename);
