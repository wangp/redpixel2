#ifndef __included_gameloop_h
#define __included_gameloop_h


#include "object.h"


extern object_t *local_player;


void game_loop ();


#endif
