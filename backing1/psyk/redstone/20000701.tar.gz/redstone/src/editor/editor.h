int editor (int argc, char *argv[]);
