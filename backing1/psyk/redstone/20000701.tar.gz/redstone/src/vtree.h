/* Virtual directory tree.  */

#define VTREE_TILES	"/tiles/"
#define VTREE_LIGHTS	"/lights/"
