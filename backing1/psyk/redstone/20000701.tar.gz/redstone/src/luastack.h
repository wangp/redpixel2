#ifndef __included_luastack_h
#define __included_luastack_h


#include <lua.h>

void lua_enablestacktraceback (lua_State *);


#endif
