DATAFILE *load_magic_datafile (const char *filename);
