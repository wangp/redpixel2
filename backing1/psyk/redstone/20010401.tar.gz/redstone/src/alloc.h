void *alloc (size_t size);
