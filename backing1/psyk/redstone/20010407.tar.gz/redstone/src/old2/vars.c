/* vars.c
 *
 * Peter Wang <tjaden@psynet.net>
 */


#include "vars.h"


/* XXX: find someplace to put these  */
int server, client;
