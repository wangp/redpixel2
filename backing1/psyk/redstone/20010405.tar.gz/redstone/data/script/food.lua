-- food.lua

store_load ("object/food.dat", "/food/")
objtype_register ("food", "burger",    "/food/burger")
objtype_register ("food", "chocolate", "/food/choc")
objtype_register ("food", "jolt-cola", "/food/jolt")
objtype_register ("food", "medipack",  "/food/medipak")
objtype_register ("food", "pizza",     "/food/pizza")
