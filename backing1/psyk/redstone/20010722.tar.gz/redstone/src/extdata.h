void register_extended_datafile ();
DATAFILE *load_extended_datafile (const char *filename);
