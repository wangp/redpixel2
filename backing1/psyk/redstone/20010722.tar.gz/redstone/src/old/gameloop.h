void game_loop (int server);
