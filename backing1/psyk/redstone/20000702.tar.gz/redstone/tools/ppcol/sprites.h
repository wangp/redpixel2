/* Allegro datafile object indexes, produced by grabber v3.0 */
/* Datafile: c:\ivan\djgpp\ppcol\contrib\allegro\addons\ppcol\sprites.dat */
/* Date: Sun Mar 15 13:58:30 1998 */
/* Do not hand edit! */

#define PAL                              0        /* PAL  */
#define SPRITE_0                         1        /* BMP  */
#define SPRITE_1                         2        /* BMP  */
#define SPRITE_2                         3        /* BMP  */
#define SPRITE_3                         4        /* BMP  */
#define SPRITE_4                         5        /* BMP  */
#define SPRITE_5                         6        /* BMP  */

