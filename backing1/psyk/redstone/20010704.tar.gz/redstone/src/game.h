#ifndef __included_game_h
#define __included_game_h


/* int game_loop (game_state_t *gs, int (*looper)(), void *looper_arg); */


#endif
