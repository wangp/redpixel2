#ifndef __included_gameclt_h
#define __included_gameclt_h


int game_client (const char *mapfile, const char *addr);


#endif
