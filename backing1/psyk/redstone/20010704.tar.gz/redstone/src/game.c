/* game.c
 *
 * Peter Wang <tjaden@users.sourceforge.net>
 */


#include "game.h"


/*
int game_loop (int (*looper)(), void *looper_arg)
{
    while (looper (looper_arg) == 0) 
	yield ();

    return 0;
}
*/
