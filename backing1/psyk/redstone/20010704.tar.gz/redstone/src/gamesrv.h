#ifndef __included_gamesrv_h
#define __included_gamesrv_h


int game_server (const char *mapfile, int num_clients);


#endif
