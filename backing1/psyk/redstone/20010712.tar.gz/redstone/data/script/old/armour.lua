-- armour.lua

store_load ("object/armour.dat", "/armour/")
objtype_register ("item", "armour-brown", "/armour/armour-brown")
objtype_register ("item", "armour-purple", "/armour/armour-purple")
objtype_register ("item", "armour-blue", "/armour/armour-blue")
