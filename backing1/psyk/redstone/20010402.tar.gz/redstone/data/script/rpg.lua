-- rpg.lua

store_load ("object/rpg.dat", "/weapon/rpg/")
objtype_register ("item", "rpg", "/weapon/rpg/pickup")
objtype_register ("item", "rpg-rockets", "/weapon/rpg/ammo")
