#ifndef __included_scripts_h
#define __included_scripts_h


void scripts_init ();
void scripts_shutdown ();
void scripts_execute (const char *filenames);


#endif
