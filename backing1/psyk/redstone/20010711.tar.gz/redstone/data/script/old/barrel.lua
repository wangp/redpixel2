-- barrel.lua

store_load ("object/barrel.dat", "/barrel/")
objtype_register ("objtile", "barrel-grey", "/barrel/barrel-grey")
objtype_register ("objtile", "barrel-red", "/barrel/barrel-red")
