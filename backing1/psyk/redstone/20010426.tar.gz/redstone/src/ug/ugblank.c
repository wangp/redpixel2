/* ugblank.c
 *
 * Peter Wang <tjaden@psynet.net>
 */


#include "ug.h"
#include "uginter.h"


ug_widget_class_t ug_blank = {
    0, 0, 0
};
