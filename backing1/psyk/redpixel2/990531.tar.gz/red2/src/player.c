/* player.c : player related */

#include "player.h"

/* 
 * 
 * TODO - this will mostly be stuff to support the scripts
 * 
 */


player_t player[MAX_PLAYERS];
