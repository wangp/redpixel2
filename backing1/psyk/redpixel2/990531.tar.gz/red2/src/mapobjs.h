#ifndef _included_mapobjs_h_
#define _included_mapobjs_h_

/* what a waste */

extern struct editmode mode_objects;


#endif
