/* common.c: globals / functions shared btn engine and map editor */

#include <allegro.h>

BITMAP *dbuf;			       /* double buffer */


				       /* FIXME THIS IS A BAD FILENAME */
