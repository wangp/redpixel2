extern BITMAP *dbuf;		       /* what a waste */
