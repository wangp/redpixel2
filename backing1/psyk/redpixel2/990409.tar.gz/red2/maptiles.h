#ifndef _included_maptiles_h_
#define _included_maptiles_h_

extern struct editmode mode_tiles;

#endif

