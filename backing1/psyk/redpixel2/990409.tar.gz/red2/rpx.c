/* rpx.c : stuff to do with .RPX files
 */

#include "rpx.h"


rpx_t rpx;


/* load_rpx:
 *  Loads an RPX file, returning zero on error.
 */
int load_rpx(char *filename)
{
    return 0;
}


/* save_rpx:
 *  Write an RPX file to disk, returning zero on error.
 */
int save_rpx(char *filename)
{
    return 0;
}

