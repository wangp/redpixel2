#ifndef _included_player_h_
#define _included_player_h_

typedef struct player
{
    /* $-start-struct player_t */
    
    unsigned int x, y;
    
    /* $-end-struct */
} player_t;

#endif
