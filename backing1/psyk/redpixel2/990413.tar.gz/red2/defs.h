/* defs.h : some #defines */
#ifndef _included_defs_h_
#define _included_defs_h_

#define TILE_W 16
#define TILE_H TILE_W


#define RPX_MAX_WIDTH	256	       /* MASSIVE!! */
#define RPX_MAX_HEIGHT	256


#endif
