/* object.c : object related stuff */


/*
 * 
 *  TODO
 * 
 * 
 */

