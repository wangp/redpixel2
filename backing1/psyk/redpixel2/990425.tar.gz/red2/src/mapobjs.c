/* ma
 * 
 *
 */ 


struct editmode mode_items =
{
    KEY_2,
    
    mdown, 
    NULL, 
    drag,
    NULL,
    
    draw_tiles,

    palette_key,
    palette_select,
    palette_draw
};

