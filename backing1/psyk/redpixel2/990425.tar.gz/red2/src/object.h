#ifndef _included_object_h_
#define _included_object_h_


typedef struct object_def
{
    /* $-start-struct object_def_t */
    
    
    /* $-end-struct */    
} object_def_t;


typedef struct object 
{
    /* $-start-struct object_t */
    
    unsigned int x, y;
    
    /* ... blah ... */
     
    /* $-end-struct */
} object_t;


#endif
