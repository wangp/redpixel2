void game_init (void);
void game_shutdown (void);
