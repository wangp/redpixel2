-- minigun.lua

store_load ("object/minigun.dat", "/weapon/minigun/")
objtype_register ("item", "ak-47", "/weapon/minigun/pickup-ak")
objtype_register ("item", "minigun", "/weapon/minigun/pickup-minigun")
objtype_register ("item", "bullets", "/weapon/minigun/ammo")
