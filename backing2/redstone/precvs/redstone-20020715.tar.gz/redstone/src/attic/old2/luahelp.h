#ifndef __included_luahelp_h
#define __included_luahelp_h


#define LS	lua_State *L


int lua_checkargs (lua_State *L, const char *argtypes);


#endif
