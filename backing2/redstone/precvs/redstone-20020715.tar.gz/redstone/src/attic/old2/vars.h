extern int server, client;
