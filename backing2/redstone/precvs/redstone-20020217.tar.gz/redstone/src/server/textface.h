#ifndef __included_textface_h
#define __included_textface_h


extern struct server_interface *server_text_interface;


#endif
