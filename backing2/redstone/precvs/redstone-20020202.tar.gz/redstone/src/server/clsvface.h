#ifndef __included_clsvface_h
#define __included_clsvface_h


void client_server_interface_add_input (const char *line);

extern struct server_interface *client_server_interface;


#endif
