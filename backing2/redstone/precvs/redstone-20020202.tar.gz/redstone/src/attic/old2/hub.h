#ifndef __included_hub_h
#define __included_hub_h


int hub_init ();
void hub_shutdown ();
void hub ();


#endif
