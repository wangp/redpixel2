-- off-objs.lua

store_load ("object/off-objs.dat", "/office-objects/")
objtype_register ("objtile", "monitor-front", "/office-objects/monitor-anim1")
objtype_register ("objtile", "monitor-left", "/office-objects/monitor-left")
objtype_register ("objtile", "monitor-right", "/office-objects/monitor-right")
objtype_register ("objtile", "brain", "/office-objects/brain")
objtype_register ("objtile", "printer", "/office-objects/printer")
objtype_register ("objtile", "tv", "/office-objects/tv-anim1")
