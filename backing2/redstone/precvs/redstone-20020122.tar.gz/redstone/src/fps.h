#ifndef __included_fps_h
#define __included_fps_h


extern volatile int frames, fps;


void fps_init ();
void fps_shutdown ();


#endif
