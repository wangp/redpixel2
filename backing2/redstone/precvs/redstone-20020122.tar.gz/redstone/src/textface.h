#ifndef __included_textface_h
#define __included_textface_h


#include "gamesrv.h"


extern game_server_interface_t game_server_text_interface;


#endif
