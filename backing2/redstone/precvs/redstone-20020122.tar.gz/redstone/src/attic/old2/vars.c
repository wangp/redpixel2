/* vars.c
 *
 * Peter Wang <tjaden@users.sourceforge.net>
 */


#include "vars.h"


/* XXX: find someplace to put these  */
int server, client;
