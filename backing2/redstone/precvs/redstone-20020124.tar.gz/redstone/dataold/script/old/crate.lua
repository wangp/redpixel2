-- crate.lua

store_load ("object/crate.dat", "/crate/")
objtype_register ("objtile", "crate-1", "/crate/crate-1")
objtype_register ("objtile", "crate-2", "/crate/crate-2")
objtype_register ("objtile", "crate-big", "/crate/crate-big")
