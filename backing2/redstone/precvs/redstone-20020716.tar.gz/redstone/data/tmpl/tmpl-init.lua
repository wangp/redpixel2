-- tmpl-init.lua

-- This file would initialise the `tmpl' addon.  Since this is not a real
-- module, there is nothing here.
