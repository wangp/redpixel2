void error (const char *message);
void errorv (const char *fmt, ...);
