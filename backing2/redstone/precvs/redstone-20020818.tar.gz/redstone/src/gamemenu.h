#ifndef __included_gamemenu_h
#define __included_gamemenu_h


int gamemenu_init (void);
void gamemenu_shutdown (void);
void gamemenu_run (void);


#endif
