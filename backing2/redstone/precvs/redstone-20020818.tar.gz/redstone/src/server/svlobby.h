#ifndef __included_svlobby_h
#define __included_svlobby_h


extern struct server_state_procs *svlobby_procs;


#endif
