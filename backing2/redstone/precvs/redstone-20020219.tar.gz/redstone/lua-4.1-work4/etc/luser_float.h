#define LUA_NUMBER		float
#define LUA_NUMBER_SCAN		"%lf"
#define LUA_NUMBER_FMT		"%.8g"
