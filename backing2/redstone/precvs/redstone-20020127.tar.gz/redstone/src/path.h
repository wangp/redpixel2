#ifndef __included_path_h
#define __included_path_h


extern char *path_share[];


void path_init (void);
void path_shutdown (void);


#endif
