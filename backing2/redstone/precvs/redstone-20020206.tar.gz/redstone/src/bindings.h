#ifndef __included_bindings_h
#define __included_bindings_h


void bindings_init (void);
void bindings_shutdown (void);


#endif
