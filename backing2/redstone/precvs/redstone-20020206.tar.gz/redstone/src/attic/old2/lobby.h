#ifndef __included_lobby_h
#define __included_lobby_h


int lobby_init ();
void lobby_shutdown ();
int lobby_update (BITMAP *);


#endif
