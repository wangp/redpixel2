#ifndef __included_game_h
#define __included_game_h


extern int server, client;

int game ();


#endif
