#ifndef __included_alloc_h
#define __included_alloc_h


#include <stdlib.h>


void *alloc (size_t size);


#endif
